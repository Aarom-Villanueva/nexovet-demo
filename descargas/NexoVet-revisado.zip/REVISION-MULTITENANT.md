# Revisión del bundle multi-veterinaria

Se revisó el bundle original con cabecera `f6cfe8de1f6e2d797fe84c51c9cae3df0d97a57e`,
que contiene cinco commits sobre `49b2f349e468ebf3a38654f79a9ac04a9418141f`.
Los documentos del bundle se trataron como descripciones a comprobar, no como
resultados ya verificados. La revisión se hizo en un worktree y bases separados.
No se modificó la base de Windows ni la base original de desarrollo.

## Resultado y correcciones

1. **Migración con el propietario de producción.** La migración 010 utiliza
   `CREATE FUNCTION ... SET app.scope`. PostgreSQL 17 rechazó ese DDL con el rol
   propietario sin superusuario. Inicialización y aprovisionamiento ahora conceden
   explícitamente `SET ON PARAMETER "app.scope"` al migrador. También se necesita
   en un servidor nuevo que reciba una restauración. No se editó la migración 010.
2. **Primer operador de plataforma.** FORCE RLS impedía el INSERT del propietario
   no superusuario en `platform_operators`: no existía una política de inserción.
   La migración nueva **012_operator_provisioning.sql** lo permite solo al rol
   propietario y en ámbito de plataforma. La API mantiene únicamente SELECT y
   su intento de crear operadores se rechaza. Nunca se concede esa capacidad a
   administradores de veterinarias.
3. **Privilegios heredados.** La comprobación de conexión aceptaba un usuario que
   heredaba un rol propietario de tablas. Ahora rechaza propiedad y privilegios
   administrativos heredados, además de los directos. Se probaron pertenencia a
   un propietario, CREATEROLE y BYPASSRLS.
4. **Exportación por veterinaria.** Los numeric y bigint podían convertirse a
   Number en JSON y perder precisión. Se serializan como cadenas en PostgreSQL,
   antes de llegar a JavaScript. Archivos y manifiesto se crean de forma exclusiva;
   un destino con archivos existentes se rechaza en lugar de sobrescribirse.
   Se gestionan errores de los streams sin excepciones no controladas.
5. **Preparación local.** `node ops/prepare-local.mjs` conserva puerto y ajustes,
   guarda una copia privada de `.env` y separa las conexiones migradora y de API.
   No conecta ni modifica PostgreSQL. No rota una contraseña de ejecución ya
   configurada y rechaza producción, destinos remotos y conexiones inconsistentes.
6. **Afirmaciones de IA.** Se retiraron tarifas/modelos no verificados de la guía.
   El umbral de tokens mide consumo conocido; no constituye una garantía de gasto.
   La pregunta libre se envía al proveedor y la validación de evidencias es
   estructural, no una comprobación semántica de cada frase.

## Comprobaciones ejecutadas

- PostgreSQL **17.11**; Node local 24 y contenedores Node 22/Caddy.
- Bundle original: 12 pruebas unitarias y 134 con PostgreSQL, tipos y compilación.
- Versión corregida: **12 unitarias + 136 PostgreSQL + 57 navegador**; tipos y build.
- **5 pruebas** del preparador local: conserva puerto 15432/configuración/copia
  previa, repetición sin rotar contraseña y rechazo de configuraciones peligrosas.
- Migración de una copia con ocho migraciones aplicadas: comparación de conteos y
  huellas de **24 tablas de partida**, normalizando tenant_id, singleton y la
  nueva vista de usuarios. Se conservaron 320 clientes, 400 mascotas, 33 usuarios
  y 428 movimientos, además de documentos, cobros y auditoría existentes.
- Propietario sin superusuario: aplica todas las migraciones, inicializa una
  veterinaria y provisiona un operador. La conexión de API rechaza ese INSERT.
- Docker: instalación vacía con propietario sin superusuario, creación y login
  de operador, alta de dos veterinarias y consultas cruzadas denegadas; compra,
  venta, cobros, reportes y CSV por HTTPS; caída/recuperación de PostgreSQL;
  respaldo, checksum, rechazos de corrupción/sobrescritura y restauración en
  otra base. Huellas/secuencias coincidentes, sesiones antiguas invalidadas y
  reingreso del operador y de ambas clínicas con aislamiento preservado.

La primera pasada del simulacro llegó a restaurar/comparar las tablas, pero falló
al recrear un contenedor por falta de espacio del entorno VFS. Se retiró la
instancia temporal de PostgreSQL de esta revisión, conservando sus dumps privados,
y se repitió el simulacro. No se retiró la instancia original de desarrollo.

No se ejecutó GitHub Actions sobre esta rama. La configuración incluye las suites
anteriores, el simulacro Docker y las pruebas del preparador local. No hay una
prueba con un proveedor externo de IA o SMTP real, ni una migración ejecutada en
la computadora de Aarom. Las pruebas de proveedor utilizan respuestas simuladas.

## Límites que siguen vigentes

- El aislamiento depende principalmente de RLS forzado, claves compuestas y el
  contexto validado de la petición. No se añadieron filtros explícitos a las
  aproximadamente 200 consultas existentes; esa segunda capa sigue pendiente.
- La restauración completa afecta a todas las veterinarias. Existe exportación
  individual, no importación selectiva automática.
- El límite de análisis se reserva de forma persistente/atómica. El umbral de
  tokens no reserva el consumo máximo de solicitudes en vuelo ni conoce los
  tokens de todas las solicitudes fallidas; usar también límites del proveedor.
- La pregunta libre puede contener lo que escriba el usuario. No se debe afirmar
  que su texto queda anonimizado por sustituir nombres del catálogo.
- Se validan formatos y claves de evidencia; la IA puede redactar conclusiones
  incorrectas que requieren revisión humana.
- No se midió nuevamente la carga del informe original. Sus cifras de PostgreSQL
  16 no se publican como capacidad garantizada de PostgreSQL 17 ni de un servidor real.
- Queda pendiente comprobar los permisos del directorio enlazado `/exports` en
  el host definitivo. La exportación local y su aislamiento sí se probaron.
- Suspensión comercial, cobros, altas y soporte siguen los procedimientos manuales
  documentados. Monitoreo externo, correo, condiciones del servicio y proveedor
  real deben configurarse antes de una puesta en servicio con datos reales.

## Entrega

La rama corregida es `fix/multitenant-validation`, construida sobre el bundle
original. No modifica main. El bundle de entrega incluye también el rediseño y
el asistente; requiere como base el commit 49b2f34 ya presente en la instalación
original. Las migraciones 001–011 se conservaron sin modificaciones.

Pasos locales en [WINDOWS-MULTITENANT.md](WINDOWS-MULTITENANT.md).
