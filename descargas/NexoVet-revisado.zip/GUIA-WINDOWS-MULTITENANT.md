# Probar la versión revisada en Windows

Para una **demostración local con datos ficticios**. No aplicar estos pasos a una
instalación de producción ni a datos reales. El procedimiento con PostgreSQL 17
se verificó en Linux/Docker; no se ejecutó Windows dentro de esta revisión.

Abre **Windows PowerShell**: el indicador empieza con `PS`. Los comandos de esta
guía usan su sintaxis. Deja Docker Desktop iniciado. Detén la aplicación anterior
con Ctrl+C. Ejecuta una línea por vez y detente si aparece un error.

## 1. Copia de la base antes de migrar

```powershell
cd C:\Users\aarom\nexovet-prueba
docker compose up -d --wait db
New-Item -ItemType Directory -Force .\.local\backups | Out-Null
$stamp = Get-Date -Format yyyyMMdd-HHmmss
$dump = "/tmp/nexovet-pre-multi-$stamp.dump"
docker compose exec -T db pg_dump -U nexovet -d nexovet_dev --format=custom --no-owner -f $dump
docker compose cp "db:$dump" ".\.local\backups\nexovet-pre-multi-$stamp.dump"
```

Confirma que se copió el archivo. Se genera dentro del contenedor y se copia como
archivo: no se usa `>` de PowerShell para un dump binario. Esta copia contiene
información privada y no se sube a GitHub. La restauración no se hace sobre la
base actual; se valida primero en un destino separado.

## 2. Importa la rama revisada

Descarga `nexovet-multi-tenant-revisado.bundle` en Descargas y confirma el nombre
real del archivo. Si el navegador agregó un sufijo, usa ese nombre en el comando.

```powershell
git status
git bundle verify "$HOME\Downloads\nexovet-multi-tenant-revisado.bundle"
git fetch "$HOME\Downloads\nexovet-multi-tenant-revisado.bundle" fix/multitenant-validation:fix/multitenant-validation
git switch fix/multitenant-validation
```

Conserva el cambio local de `compose.yaml` que publica PostgreSQL en 15432.
La rama revisada no cambia ese archivo. Si Git bloquea el cambio de rama, revisa
los archivos que menciona; no fuerces el cambio ni descartes trabajo local.
No necesitas importar primero los bundles anteriores: este incluye sus commits.

## 3. Prepara las dos conexiones y migra

```powershell
npm ci
node ops/prepare-local.mjs
npm run db:migrate
npm run db:seed
npm run auth:demo-users
```

El preparador guarda una copia exacta de `.env` en `.local/config-backups` y
conserva el puerto existente (15432). Si falta MIGRATION_DATABASE_URL, utiliza la
conexión propietaria anterior. DATABASE_URL pasa a un usuario distinto con una
contraseña local aleatoria. Si ya tenía una conexión de ejecución válida, la
conserva. No imprime contraseñas ni claves de IA.

`db:migrate` crea/actualiza el usuario de ejecución y aplica migraciones pendientes.
En esta instalación Docker local el usuario `nexovet` es superadministrador, como
lo configura el Compose de desarrollo. Si tu base usa otro propietario sin permiso
para crear roles, hay que aprovisionarlos con el administrador de ese servidor;
no habilites ALLOW_UNSAFE_DB_ROLE para saltarte el aislamiento.

Tus datos anteriores quedan en la veterinaria `principal`. Si era una base vacía,
la semilla crea `demo`. Las cuentas anteriores conservan contraseñas. Su archivo
local está en `.local/demo-credentials-nexovet_dev.json`; no lo compartas.

No vuelvas a migrar una base actualizada con una rama anterior. Para volver a una
versión previa, prepara otra base desde el respaldo y la versión compatible.

## 4. Crea tu operador de plataforma una sola vez

Es una cuenta distinta del administrador de una clínica. Estos datos son de demo;
la contraseña la eliges privadamente en tu terminal.

```powershell
$env:NEW_USER_EMAIL = 'operador@example.invalid'
$env:NEW_USER_NAME = 'Operador local'
$env:NEW_USER_PLATFORM_OPERATOR = 'true'
$secret = Read-Host 'Contraseña nueva de 12 a 128 caracteres' -AsSecureString
$pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try {
    $env:NEW_USER_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    npm run auth:create-user
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    Remove-Item Env:NEW_USER_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:NEW_USER_PLATFORM_OPERATOR -ErrorAction SilentlyContinue
    Remove-Item Env:NEW_USER_EMAIL -ErrorAction SilentlyContinue
    Remove-Item Env:NEW_USER_NAME -ErrorAction SilentlyContinue
}
```

Si la cuenta ya existe, el comando la rechaza en lugar de sobrescribirla. Conserva
la contraseña elegida. Esta cuenta no obtiene acceso clínico automáticamente.

## 5. Inicia y comprueba

```powershell
npm run dev
```

- Abre http://localhost:5173/ingresar.
- Con tu cuenta clínica anterior puedes operar en `principal`.
- Con `operador@example.invalid` y la contraseña que elegiste entra en
  http://localhost:5173/plataforma. Ahí puedes crear otra veterinaria, provisionar
  su primer administrador, consultar límites y registrar pagos ficticios.
- Comprueba con dos cuentas que no aparezcan clientes o documentos de otra clínica.
- Sin proveedor de IA configurado se muestran hechos y configuración pendiente;
  no se generan respuestas simuladas.

Opcional, en otra terminal dentro del proyecto: `npm run demo:activity` añade ventas
ficticias para los reportes. No es necesario para migrar ni para iniciar sesión.

Para verificar las pruebas del preparador local:
`node --test tests/operations/local-config.test.mjs`.
Las suites de base requieren además `nexovet_test`, separada de tu base de demo;
no ejecutes tests contra una clínica real.
